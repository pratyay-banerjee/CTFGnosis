#ifndef _LOGGER_H_
#define _LOGGER_H_

#include <sys/types.h>

pid_t logger_start();

#endif
