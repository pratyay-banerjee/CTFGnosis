#ifndef _STRCPY_H_
#define _STRCPY_H_
void scp(char* dest, const char* src);
#endif
