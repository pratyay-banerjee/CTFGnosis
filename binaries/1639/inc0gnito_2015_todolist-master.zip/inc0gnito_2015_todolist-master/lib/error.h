#ifndef _ERROR_H_
#define _ERROR_H_

void exit_on_error(const char* error) __attribute__((noreturn));

#endif
