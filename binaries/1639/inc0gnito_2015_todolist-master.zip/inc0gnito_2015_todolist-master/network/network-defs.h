#ifndef _SERVICE_FUNCTION_H_
#define _SERVICE_FUNCTION_H_

typedef void __service_function_t(void);
typedef __service_function_t* service_function_t;

#endif
