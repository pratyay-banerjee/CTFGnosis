# inc0gnito_2015_todolist
inc0gnito 2015 ctf todolist source &amp; exploit

exploit uses pwntools from Gallopsled
