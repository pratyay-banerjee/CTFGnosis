#include "config.h"

char mysql_user[USER_MAX] = {0,};
char mysql_pass[PASS_MAX] = {0,};
char mysql_dbname[DBNAME_MAX] = {0,};
