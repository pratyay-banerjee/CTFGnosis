#ifndef __PERMISSION_H__
#define __PERMISSION_H__

#include <stdbool.h>

bool drop_privileges();
bool sandbox();

#endif
